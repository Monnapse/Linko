# Linko
Connect Python and HTML to pass varius Methods.