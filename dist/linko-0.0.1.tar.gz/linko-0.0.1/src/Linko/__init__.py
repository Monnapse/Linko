import re

class Linko:
    def __init__(self, Methods: set = None):
       """
       Connect Python and HTML to pass varius Methods.

       [[! function() !]]
       [[! valueHere !]]
       [[! valueHere !]]
       """
       self.Methods = Methods

    def add_method(self, Method: str, Value: any):
        self.Methods[Method] = Value

    def render(self, content: str):
        pattern = r'\[\[! (.*?) !\]\]'
        matches = re.findall(pattern, content)

        for match in matches:
            print(match)