# Linko
Connect Python and HTML to pass varius Methods.

Function Methods Not Added Yet

# UPDATES

## 0.0.13
* added functions

## 0.0.12
* added global methods

## 0.0.11
* added render_layers