# Linko
Connect Python and HTML to pass varius Methods.

Function Methods Not Added Yet